alert("connected");
var disp = document.querySelector("#disp");
  
 function clickEqlTo() {
    if(!checkMath()) {
      // regexp /\d+/g looks for digits
      var exp1 = /\d+/g 
      ///[\+\-\*\/]+/g math ops
      var exp2 = /[\+\-\*\/]+/g
      // var nums = $("#disp").html
      //checks the div disp with regexp to match digits and stores them
      var numbers = disp.innerHTML.match(exp1);
      //checks the disp's regexp to match maths operations and stores them
      var mathops = disp.innerHTML.match(exp2);
      while(mathops.length>0) {
        //perform +,-,*,/ based on the display
        if(mathops.includes('*')) {
          var indexOfMul = mathops.indexOf('*');
          //parses the number before the * in binary form if * isnt the first element. else multiplies first and 2nd number
          var mul = ( indexOfMul!=0 ? parseInt(numbers[indexOfMul-1],2) : parseInt(numbers[indexOfMul],2) ) * parseInt(numbers[indexOfMul+1],2);
          //removes the operands and sets the result in the numbers array
          numbers.splice(indexOfMul,2);
          numbers.splice(indexOfMul,0,mul.toString(2));
          mathops.splice(indexOfMul,1);
        } else if (mathops.includes('/')) {
          //parses the number before the * in binary form if / isnt the first element. else divides first num by the 2nd
          var indexOfDiv = mathops.indexOf('/');
          var division = ( indexOfDiv!=0 ? parseInt(numbers[indexOfDiv-1],2) : parseInt(numbers[indexOfDiv],2) ) / parseInt(numbers[indexOfDiv+1],2);
          //removes divisor and dividend
          numbers.splice(indexOfDiv,2);
          // sets the result to numbers array
          numbers.splice(indexOfDiv,0,division.toString(2));
          //removes / from the mathops array
          mathops.splice(indexOfDiv,1);
        } else if (mathops.includes('+')) {
          var indexOfSum = mathops.indexOf('+');
          var sum = ( indexOfSum!=0 ? parseInt(numbers[indexOfSum-1],2) : parseInt(numbers[indexOfSum],2) ) + parseInt(numbers[indexOfSum+1],2);
          numbers.splice(indexOfSum,2);
          numbers.splice(indexOfSum,0,sum.toString(2));
          mathops.splice(indexOfSum,1);
        } else {
          var indexOfSub = mathops.indexOf('-');
          var sub = ( indexOfSub!=0 ? parseInt(numbers[indexOfSub-1],2) : parseInt(numbers[indexOfSub],2) )- parseInt(numbers[indexOfSub+1],2);
          numbers.splice(indexOfSub,2);
          numbers.splice(indexOfSub,0,sub.toString(2));
          mathops.splice(indexOfSub,1);
        }  
      }
      //sets the display to the result of the operation
      disp.innerHTML = numbers[0].toString(2);
    } else {
      //alerts if no num entered
      alert("Enter a number")
    }
  }

  function checkMath(){
    //check if it is a maths operation
    if(disp.innerHTML.endsWith("+") || disp.innerHTML.endsWith("-") || disp.innerHTML.endsWith("*") || disp.innerHTML.endsWith("/")){
      return true;
    }
  }
  
  function clickZero() {
    //sets display to 0 when 0 is pressed
    disp.innerHTML +="0";
  }
  
  function clickOne() {
    //sets display to 1 when 1 is pressed
    disp.innerHTML +="1";
  }

  //sets the display with the operation appended to the number
  
  function clickSum() {
    if(disp.innerHTML.length!=0 && !checkMath()){
        disp.innerHTML +="+";
       }
  }  
  
  function clickSub() {
    if(disp.innerHTML.length!=0 && !checkMath()){
        disp.innerHTML +="-";
       }
  }

  function clickMul() {
    if(disp.innerHTML.length!=0 && !checkMath()){
        disp.innerHTML +="*";
       }
  }

  function clickDiv() {
    if(disp.innerHTML.length!=0 && !checkMath()){
        disp.innerHTML +="/";
      }
  }

//clears the screen
  function clickClr() {
    disp.innerHTML = "";
  }

  