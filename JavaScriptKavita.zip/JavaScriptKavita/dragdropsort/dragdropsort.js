alert("connected");

//prevent default allows the drop event
function allowDrop(ev) {
    ev.preventDefault();
}

//sets the data corresponding to the data transfer of the event
function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

//gets the data and appends it to the data div
function drop(ev) {
    ev.preventDefault();
    //gets the data
    var data = ev.dataTransfer.getData("text");
    //appends it to the droppable region div
    ev.target.appendChild(document.getElementById(data));
    sortDivs();
}

function sortDivs(){
    //sorts the elemets in the p elements in ascending order
    var elem = document.querySelectorAll(".droppable .box .p");
    var arr = [];
    for(var i=0;i<elem.length;i++){
    	console.log(elem[i].innerHTML);
    	arr.push(elem[i].innerHTML);
	}
	arr.sort(function(a, b){return a - b});
	console.log(arr);
	for(var i=0; i<elem.length; i++){    
    	elem[i].innerHTML = arr[i];
	}
}
