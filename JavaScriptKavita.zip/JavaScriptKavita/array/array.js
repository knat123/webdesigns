//alert("connected");
var arr=[21, 13, 2, 19, 40, 17, 49, 34, 91, 8];

var ul=document.createElement('ul');
document.body.appendChild(ul);

for(var i=0; i<arr.length; i++){ 
	var li=document.createElement('li');
	var liText ="";
	 ul.appendChild(li);   
    if (i<5) {
        console.log(arr[i]+" is at position "+i+ " (Available in First half of array)");
        liText = arr[i]+" is at position "+i+ " (Available in First half of array)";
    }
    else{
    	console.log(arr[i]+" is at position "+i+ " (Available in Second half of array)");
    	liText = arr[i]+" is at position "+i+ " (Available in Second half of array)";

    }
    li.innerHTML = liText;
    
}
    