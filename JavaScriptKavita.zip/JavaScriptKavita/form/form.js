alert("connected");
// document.body.onload = createForm;

// function addElement () { 
//   // create a new div element 
//   var newDiv = document.createElement("div"); 
//   newDiv.setAttribute('id','div1');
//   // and give it some content 
//   var input = document.createElement("input");
//   input.setAttribute('type', 'text');
//   input.setAttribute('placeholder','Enter');
//   // add the text node to the newly created div
//   newDiv.appendChild(input);  

//   // add the newly created element and its content into the DOM 
//   var currentDiv = document.getElementById("div1"); 
//   document.body.insertBefore(newDiv, currentDiv); 
// }
document.getElementById("bottomhead").style.display = 'none';
document.getElementById("bottom").style.display = 'none';
// newDiv.id = "div1";
var f = document.createElement("form");
//f.setAttribute('method',"post");
//f.setAttribute('action',"submit.php");
f.id="formid";
document.getElementById('top').appendChild(f);
document.querySelector("#formid").classList.toggle("form",true);
var count = 0;
var classCount = "";

$("#create").click(function(){
   		addElement();
   		
   });

$("#preview").click(function(){
   		previewForm();
   		
   });

// $("[type='button']").click(function(){
// 	var classNumber = $(this).attr("class");
// 	console.log(classNumber);
// 	var num = "."+classNumber.split(" ")[0];
// 	 $("num").remove();
// })




function addElement(){
	count++;
	//div
	var div1 = document.createElement("div");
	div1.setAttribute("class","div1");
	div1.id = count;
	// add element to the form
	var f = document.querySelector("#formid");
	f.appendChild(div1);
	//create input element
	classCount = "count"+count;
	var inputText = createText();
	//create a selectlist
	var selectItem = createSelect();

	//create remove button
	var removeBtn = createRemove();

	//append the items into div1
	div1.appendChild(inputText);
	div1.appendChild(selectItem);
	div1.appendChild(removeBtn);
	console.log(count);

}

function createText(){
	var inpt = document.createElement("input");
	inpt.type = "text";
//inpt.name = "user_name1";
// i.id = "user_name1";
	inpt.setAttribute("class",classCount);
	inpt.placeholder ="Enter Field Label";
	return inpt;
}

function createSelect(){
	var selectArr = ["Select List","Text"];
	var s = document.createElement("select");
	s.id=classCount;
	s.name="select1"
	s.setAttribute("class",classCount);

	//Create and append the options
	for (var i = 0; i < selectArr.length; i++) {
    var option = document.createElement("option");
    option.value = selectArr[i];
    option.text = selectArr[i];
    s.appendChild(option);

	}
	return s;
}

function createRemove(){
	//create a button
	var remove = document.createElement("BUTTON");
	var classRemove = classCount + ' remove';
	remove.setAttribute("class",classRemove);
	remove.innerHTML= "Remove";
	remove.type = "button";
	remove.addEventListener("click",function(){
		console.log(classCount);
		var removeThis = "."+classCount;
		console.log(removeThis);
		$(removeThis).remove();
		count--;

	});
	return remove;
}

function previewForm(){
	// $("body").append(div2);
	// var bottomdiv = document.getElementById("bottom");
	document.getElementById("create").disabled = true;
	document.getElementById("bottomhead").style.display = 'block';
	bottom.style.display = 'block';
	//select whats displayed in create block
	//var formDiv="";
	//var formDiv = document.querySelectorAll(".div1");
	//console.log(formDiv);
	//for(var i=0;i<formDiv.length;i++){
	var id = "";
	var elem = "";
	var div2 = "";
	for(i=1;i<=count;i++){
		id = "count"+i;
		console.log(id);
		console.log(document.getElementById(id));
		elem = document.getElementById(id);
	//var bottomdiv = document.querySelector("#bottom");
	//for(var i=0; i<formDiv.length; i++){
		div2 = document.createElement("div");
	    div2.setAttribute("class","div2");
	    bottom.appendChild(div2);//append div2 
		console.log(elem);
		var labelInput = "";
		var label2 = "";
		var idforItem = "selectpre"+i;
		if(elem[elem.selectedIndex].value == 'Select List'){
			labelInput = 'Select List Label ';
			label2 = document.createElement("label");
			label2.for=idforItem;
			label2.innerHTML = labelInput;
			var selectDisp = ["Select List","Text"];
			var s = document.createElement("select");
			s.id="bottom"+i;
			// var div2 = document.querySelector("#bottom");
			div2.appendChild(label2);
			div2.appendChild(s);

			for (var x = 0; x < selectDisp.length; x++) {
			    var option = document.createElement("option");
			    option.value = selectDisp[x];
			    option.text = selectDisp[x];
			    s.appendChild(option);
			}
		}
		else{
			labelInput= 'Text Field Label '
			label2 = document.createElement("label");
			idforItem = "textpre"+i;
			label2.for=idforItem;
			label2.innerHTML = labelInput;
			var inp = document.createElement("input");
			inp.type = "text";
			inp.id = idforItem;
			//inp.name = "user_name1";
			//label2.style.display = 'block';
			div2.appendChild(label2);
			div2.appendChild(inp);
			// i.id = "user_name1";
			// i.placeholder ="Enter Field Label";
		}
		console.log(count);
		console.log(i);
	}
	document.getElementById("preview").disabled = true;
}
