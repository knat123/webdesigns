// alert("connected");
var typingTimer;                //timer identifier
var doneTypingInterval = 3000;  //time in ms, 3 second for example
var alertstate = "";

		
//on keyup, start the countdown
$("#email").on('keyup', function () {
  clearTimeout(typingTimer);
  typingTimer = setTimeout(doneTypingEmail, doneTypingInterval);
});

//on keydown, clear the countdown 
$("#email").on('keydown', function () {
  clearTimeout(typingTimer);
});

//after user finishes typing, do something
function doneTypingEmail () {
  //do something
    var email = document.querySelector("#email");
    if(!email.checkValidity()){
	document.getElementById("em").innerHTML = email.validationMessage;
  }
}

$("#dateTest").on('keyup', function () {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(doneTypingDate, doneTypingInterval);
});

//on keydown, clear the countdown 
$("#dateTest").on('keydown', function () {
    clearTimeout(typingTimer);
});

//after user  finishes typing do something
function doneTypingDate () {
  //do something
 // test if the dob is valid date
    var ret = testDate();
    if(ret == true){
    $( "#altbtn" ).click(function() {
    alert(alertstate);
    });
  }
}



// test if the dob is valid date
function testDate(sender, args) {
    var result = isDate(document.getElementById('dateTest').value);
    console.log(document.getElementById('dateTest').value);
    console.log(result);
	//invalid date statement
	if (result == false){
    $('#result').html("Date of Birth must be of the form DD-MON-YYYY");

	}
	else{
        // calculate the years and days
		var yyyymmdd = convertdate(); //date in form YYYY-MM-DD for easy comparing
		var birthdate = new Date(yyyymmdd);
		var curryeardob = new Date(yyyymmdd);
		var ageInyears = calcAgeInYears(birthdate);
		var curYear = (new Date()).getFullYear(); //gets the current year
		curryeardob.setFullYear(curYear);
		var today = new Date();
		//checks if birthday has not happened this year
		if(today < curryeardob){
			//set the year of comparison as last year to get number of days
				curryeardob.setFullYear(curYear-1); 
			}
		console.log(curryeardob);
		var oneDay = 24*60*60*1000; //milliseconds
		var days = Math.round(Math.abs((today.getTime() - curryeardob.getTime())/(oneDay))); //number of days since last bday
		console.log(ageInyears);
		console.log(days);
		alertstate = "Your age is "+ageInyears+ " and "+days+ " days";
	   return true;
		
	}
	
}

//function to check the date
function isDate(dateVal) {


    if (dateVal == '') return false;

    //Declare Regex  
    var rxDatePattern = /^(\d{1,2})(\/|-)([a-zA-Z]{3})(\/|-)(\d{4})$/;

    var dtArray = dateVal.match(rxDatePattern); //check the format for correctness

    if (dtArray == null) return false;

    var dtDay = parseInt(dtArray[1]);
    var dtMonth = dtArray[3];
    var dtYear = parseInt(dtArray[4]);
    
    // need to change to lowerCase because switch is case sensitive
    switch (dtMonth.toLowerCase()) {
        case 'jan':
            dtMonth = '01';
            break;
        case 'feb':
            dtMonth = '02';
            break;
        case 'mar':
            dtMonth = '03';
            break;
        case 'apr':
            dtMonth = '04';
            break;
        case 'may':
            dtMonth = '05';
            break;
        case 'jun':
            dtMonth = '06';
            break;
        case 'jul':
            dtMonth = '07';
            break;
        case 'aug':
            dtMonth = '08';
            break;
        case 'sep':
            dtMonth = '09';
            break;
        case 'oct':
            dtMonth = '10';
            break;
        case 'nov':
            dtMonth = '11';
            break;
        case 'dec':
            dtMonth = '12';
            break;
    }

    // convert date to number
    dtMonth = parseInt(dtMonth);
    
    if (isNaN(dtMonth)) return false;
    else if (dtMonth < 1 || dtMonth > 12) return false;
    else if (dtDay < 1 || dtDay > 31) return false;
    else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31) return false;
    else if (dtMonth == 2) {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay > 29 || (dtDay == 29 && !isleap)) return false;
    }

    return true;

}

//convert the date to YYYY-MM-DD
function convertdate(){
	var dob = document.getElementById("dateTest").value;
	var date = dob.split("-");
	var mon = date[1];
	var months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun','jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
	console.log(typeof(date[1]));
	for(var j=0;j<months.length;j++){
    if(mon.toLowerCase()==months[j]){
         date[1]=months.indexOf(months[j])+1;
     }                      
} 
if(date[1]<10){
    date[1]='0'+date[1];
}                        
var formattedDate = date[2]+"-"+date[1]+"-"+date[0];
return formattedDate;
}


function calcAgeInYears(birthday) { // birthday is a date
	console.log(birthday);
    var ageDifMs = Date.now() - birthday.getTime();
    var ageDate = new Date(ageDifMs); // miliseconds from epoch
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}

