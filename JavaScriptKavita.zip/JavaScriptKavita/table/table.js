	alert("connected");
	 var data = [
{"ID": "101",
	"Name": "The Good Parts ",
	"Category": "JS",
	"Detail":
		{
			"Price": "100$",
			"Page Count": "200",
			"Paper Type": "Wax paper"
		}
},
{"ID": "102",
	"Name": "The Definitive Guide ",
	"Category": "JavaScript",
	"Detail":
		{
			"Price": "70$",
			"Page Count": "200",
			"Paper Type": "Leather paper"
		}
},
{"ID": "103",
	"Name": "CoffeeScript ",
	"Category": "Scripting",
	"Detail":
		{
			"Price": "90$",
			"Page Count": "200",
			"Paper Type": "Kraft paper"
		}
},
{"ID": "104",
	"Name": "Exploring ES6 ",
	"Category": "Browser",
	"Detail":
		{
			"Price": "40$",
			"Page Count": "200",
			"Paper Type": "Book paper"
		}
}
];
	var items = [];
	$.each(data, function(key, value){
		items.push( "<tr>");
		items.push("<td id='" + key + "'>" + value.ID + "</td>" );
		items.push("<td id='" + key + "'>" + value.Name + "</td>" );
		items.push("<td id='" + key + "'>" + value.Category + "</td>" );
		items.push("<td id='" + key + "'>" + value.Detail.Price + "</td>" );
		items.push("<td id='" + key + "'>" + value.Detail["Page Count"] + "</td>" );
		items.push("<td id='" + key + "'>" + value.Detail["Paper Type"] + "</td>" );
		items.push( "<tr>");
	});
	
	$( "<tbody/>" , { html: items.join( "" ) }).appendTo( "table" );

$("#vertical").click(function(){
	$("p").toggleClass("rotated",true);
});