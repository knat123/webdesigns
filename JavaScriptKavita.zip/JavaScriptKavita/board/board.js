 alert("connected");
$(document).ready(function(){
  // jQuery to buildboard
   buildBoard('.chessboard');

//before each pattern is set the board is reset
   $("#pattern1").click(function(){
   		resetPattern();
   		$("td").toggleClass("green",true);
   		
   })

   $("#pattern2").click(function(){
   		resetPattern();
   		applyPattern2();
   })

   $("#pattern3").click(function(){
   		resetPattern();
   		applyPattern3();
   })

			  }
		  
);

function buildBoard(cssclassName){
  //builds the board in layers and appends it to the tables as rows and sets of columns
	var space = 1;
	var layer = "";
for (var r=0; r<8; r++) {
  var col = "";
  for (var c=0; c<8; c++) {
  	if(r==0||c==0||r==7||c==7)
  	{
  		layer= "layer1";
  	}
  	else if(r==1||c==1||r==6||c==6)
  	{
  		layer= "layer2";
  	}
  	else if(r==2||c==2||r==5||c==5){
  		layer= "layer3";
  	}
  	else if(r==3||c==3||r==4||c==4){
  		layer = "layer4";
  	}
   col += "<td class='"+layer+"' data-row='"+r+"' data-pos='"+space+"'></td>"; space++; }
  $(cssclassName).append("<tr>"+col+"</tr>");
}
}

function applyPattern2(){
  //sets the diagonal pattern of red 2nd pattern
  var row0 = document.querySelectorAll("[data-row='0']");
  var row1 = document.querySelectorAll("[data-row='1']");
  var row2 = document.querySelectorAll("[data-row='2']");
  var row3 = document.querySelectorAll("[data-row='3']");
  var row4 = document.querySelectorAll("[data-row='4']");
  var row5 = document.querySelectorAll("[data-row='5']");
  var row6 = document.querySelectorAll("[data-row='6']");
  var row7 = document.querySelectorAll("[data-row='7']");

  for(var i=0;i<8;i++){
  	if(i==0 || i==7){
  		row0[i].classList.toggle("red",true);
  		row7[i].classList.toggle("red",true);
  	}
  	else if(i==1||i==6){
  		row1[i].classList.toggle("red",true);
  		row6[i].classList.toggle("red",true);
  	}
  	else if(i==2||i==5){
  		row2[i].classList.toggle("red",true);
  		row5[i].classList.toggle("red",true);
  	}
  	else if(i==3||i==4){
  		row3[i].classList.toggle("red",true);
  		row4[i].classList.toggle("red",true);
  	}
  }
  
}

function applyPattern3(){
  //sets the 3rd pattern
	$(".layer1").toggleClass("red",true);
	$(".layer2").toggleClass("green",true);
	$(".layer3").toggleClass("white",true);
	$(".layer4").toggleClass("blue",true);

}

function resetPattern(){
	$("td").toggleClass("red",false);
	$("td").toggleClass("blue",false);
	$("td").toggleClass("white",false);
	$("td").toggleClass("green",false);
}

